
This is a modified version of SubKiller.java. The Y axis has been unlocked and the controls have been altered.

Much of the time spent on this lab was troubleshooting JavaFX and studying each of the provided examples. With more time, I would consider altering this program further, into a more developed game.
